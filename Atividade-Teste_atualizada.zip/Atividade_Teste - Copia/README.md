# Projeto de Automação de Testes - Sauce Demo

Este projeto contém os scripts de automação de testes para o site [https://www.saucedemo.com/v1/](https://www.saucedemo.com/v1/), como parte da avaliação prática de automação web.

As ferramentas utilizadas foram:
* **Framework de Automação:** Cypress
* **Linguagem:** JavaScript

## Funcionalidades Automatizadas

Foram automatizados os seguintes fluxos, conforme solicitado:
* **Login e Logout:** Validação de login com sucesso, falha e logout.
* **Produtos:** Validação da listagem, visualização de detalhes e ordenação de produtos.
* **Carrinho:** Adicionar e remover produtos do carrinho, validando o conteúdo.
* **Checkout:** Processo completo de finalização da compra, desde o preenchimento de dados até a mensagem de sucesso.

## Pré-requisitos

Antes de executar os testes, certifique-se de ter o [Node.js](https://nodejs.org/) instalado em sua máquina.

## Instalação

1. Clone este repositório para sua máquina local.
2. Navegue até a pasta raiz do projeto.
3. Instale as dependências (Cypress) com o comando:

```bash
npm install
