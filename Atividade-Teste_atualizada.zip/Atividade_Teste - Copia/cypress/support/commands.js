// Adiciona o comando de login customizado
Cypress.Commands.add('login', (username, password) => {
  cy.visit('/v1/'); // Garante que estamos na página de login
  cy.get('[data-test="username"]').type(username);
  cy.get('[data-test="password"]').type(password);
  cy.get('#login-button').click();
});