describe('Funcionalidade: Checkout', () => {

  it('Deve finalizar a compra com sucesso do início ao fim', () => {
   // --- PREPARAÇÃO ---
   cy.login('standard_user', 'secret_sauce');

   // Garante que a página de produtos carregou
   cy.get('.inventory_list').should('be.visible');

   // **LINHA CORRIGIDA:** Usa o seletor exato do botão do produto
   cy.contains('.inventory_item', 'Sauce Labs Backpack').find('button').click();

   // Validação crítica que o item foi adicionado
   cy.get('.shopping_cart_badge').should('have.text', '1');

    // --- TESTE DE CHECKOUT ---
    // 1. Ir para o carrinho e clicar em checkout
    cy.get('.shopping_cart_link').click();
    cy.contains('CHECKOUT').click();
    cy.url().should('include', '/checkout-step-one.html');

    // 2. Preencher dados obrigatórios
    cy.get('[data-test="firstName"]').type('Arthur');
    cy.get('[data-test="lastName"]').type('Teste');
    cy.get('[data-test="postalCode"]').type('12345000');
    cy.get('input[type="submit"]').click();

    // 3. Validar resumo da compra
    cy.url().should('include', '/checkout-step-two.html');
    cy.get('.cart_item').should('have.length', 1);
    cy.get('.summary_total_label').should('be.visible');

    // 4. Finalizar compra e validar mensagem de sucesso
    cy.contains('FINISH').click();
    cy.url().should('include', '/checkout-complete.html');
    // Abordagem final que ignora se é maiúsculo ou minúsculo
    cy.get('.complete-header').should('have.text', 'THANK YOU FOR YOUR ORDER');
  });

});