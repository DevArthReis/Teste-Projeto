describe('Funcionalidade: Produtos', () => {

  // Este bloco é executado ANTES de CADA teste neste arquivo
  beforeEach(() => {
    // Realiza o login para garantir que estamos na página de produtos
    cy.login('standard_user', 'secret_sauce');
  });

  it('Deve validar a exibição da lista de produtos após login', () => {
    cy.get('.inventory_list').should('be.visible');
    cy.get('.inventory_item').should('have.length.gt', 0); // Garante que a lista não está vazia
  });

  it('Deve visualizar detalhes de um produto', () => {
    // Clica no nome de um produto específico
    cy.get('.inventory_item_name').contains('Sauce Labs Backpack').click();

    // Valida se fomos para a página de detalhes correta
    cy.get('.inventory_details_name').should('have.text', 'Sauce Labs Backpack');
    cy.get('.inventory_details_price').should('be.visible');
  });

  it('Deve ordenar produtos por nome (Z a A)', () => {
    // Seleciona a opção de ordenação "Name (Z to A)"
    cy.get('.product_sort_container').select('za');

    // Valida se o primeiro item da lista é o correto para essa ordenação
    cy.get('.inventory_item_name').first().should('have.text', 'Test.allTheThings() T-Shirt (Red)');
  });

  it('Deve ordenar produtos por preço (menor para maior)', () => {
    // Seleciona a opção de ordenação "Price (low to high)"
    cy.get('.product_sort_container').select('lohi');

    // Valida se o primeiro item da lista tem o menor preço
    cy.get('.inventory_item_price').first().should('have.text', '$7.99');
  });
});